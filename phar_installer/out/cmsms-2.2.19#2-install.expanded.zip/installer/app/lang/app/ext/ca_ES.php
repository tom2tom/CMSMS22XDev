<?php
$lang['action_freshen'] = 'Refrescant / Reparant %s instal.lació  de CMS';
$lang['action_install'] = 'Creant un nou web %s CMSMS';
$lang['action_upgrade'] = 'Actualitzant un Web CMSMS a versió %s';
$lang['advanced_mode'] = 'Habilita el mode avançat';
//$lang['email_accountinfo_message'] = TODO retranslation needed
//$lang['email_accountinfo_message_exp'] = TODO retranslation needed
//$lang['error_delete'] = ''; TODO translation needed
//$lang['remove_langs'] = 'TODO translate Remove translations %s';
?>
