<?php
/*
 * Replacement for deprecated Smarty-internal modifier
 * This is registered as a modifier instead of deploying a security
 * policy which enables direct use of the PHP function
 */
function smarty_modifier_addslashes($string)
{
	return addslashes($string);    
}
