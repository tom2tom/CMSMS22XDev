<?php

namespace cms_autoinstaller;

use __appbase\utils;
use cms_autoinstaller\wizard_step;
use cms_config;
use cms_siteprefs;
use CmsApp;
use CMSMS\Database\compatibility;
use CMSMS\Database\Connection;
use CMSMS\Database\ConnectionSpec;
use Exception;
use RuntimeException;
use const CMS_DB_PREFIX;
use const CONFIG_FILE_LOCATION;
use function __appbase\get_app;
use function __appbase\lang;
use function __appbase\smarty;
use function cmsms;

class wizard_step8 extends wizard_step
{
    protected function process()
    {
        // nothing here
    }

    private function db_connect($choices)
    {
        $spec = new ConnectionSpec();
        if( isset($choices['dbms']) ) {
            $spec->type = $choices['dbms'];
            $spec->host = $choices['db_hostname'];
            $spec->username = $choices['db_username'];
            $spec->password = $choices['db_password'];
            $spec->dbname = $choices['db_name'];
            $spec->port = isset($choices['db_port']) ? $choices['db_port'] : 0; //TODO mysqli default null not 0
            $spec->prefix = $choices['db_prefix'];
        }
        else {
            $spec->type = $choices['dbtype'];
            $spec->host = $choices['dbhost'];
            $spec->username = $choices['dbuser'];
            $spec->password = $choices['dbpass'];
            $spec->dbname = $choices['dbname'];
            $spec->port = isset($choices['dbport']) ? $choices['dbport'] : 0; // TODO default null ?
            $spec->prefix = $choices['dbprefix'];
        }
        if( !defined('CMS_DB_PREFIX') ) { //sometimes undefined when installer is running
            define('CMS_DB_PREFIX',$spec->prefix);
        }
        $db = Connection::initialize($spec);
        //when debugging $app=get_app();$destdir=$app->get_destdir();$logfile=$destdir.'/installer.log';
        $db->SetErrorHandler(function() { //when debugging use ($db, $logfile)
            // normally do nothing
            // when debugging error_log('step 8 db error "'.$db->ErrorMsg()."\"\n",3,$logfile);
        });
        $db->Execute("SET NAMES 'utf8'");
        compatibility::noop(); // autoload the db class
        CmsApp::get_instance()->_setDb($db);
        return $db;
    }

    private function connect_to_cmsms($destdir)
    {
        if( is_file("$destdir/lib/include.php") ) {
            global $CMS_INSTALL_PAGE, $DONT_LOAD_DB, $DONT_LOAD_SMARTY, $CMS_VERSION;
            $CMS_INSTALL_PAGE = 1;
            $DONT_LOAD_DB = 1;
            $DONT_LOAD_SMARTY = 1;
            $app = get_app();
            if( $app->in_phar() ) {
                global $CMS_PHAR_INSTALLER;
                $CMS_PHAR_INSTALLER = 1; //TODO used only to block core Smarty use c.f. $DONT_LOAD_SMARTY
            }
            if( empty($CMS_VERSION) ) {
                $CMS_VERSION = $app->get_dest_version(); // default value
            }
            // setup and initialize the cmsms API's
            // note DONT_LOAD_DB and DONT_LOAD_SMARTY are used.
            require_once "$destdir/lib/include.php";
            // $config does [did?] not define this when installer is running.
            if( !defined('CMS_DB_PREFIX') ) {
                $config = cms_config::get_instance();
                define('CMS_DB_PREFIX',$config['db_prefix']);
            }
        }
        else {
            throw new RuntimeException('Could not find include.php file in destination');
        }
    }

    private function do_install()
    {
        $app = get_app();
        $wiz = $this->get_wizard();

        try {
            $destdir = $app->get_destdir();
            if( !$destdir ) throw new Exception(lang('error_internal',800));

            $adminaccount = $wiz->get_data('adminaccount');
            if( !$adminaccount ) throw new Exception(lang('error_internal',801));

            $choices = $wiz->get_data('config');
            if( !$choices ) throw new Exception(lang('error_internal',803));

            $siteinfo = $wiz->get_data('siteinfo');
            if( !$siteinfo ) throw new Exception(lang('error_internal',804));

            $this->write_config($choices,$destdir);
            $this->connect_to_cmsms($destdir);

            // connect to the database, ready for downstream use
            $db = $this->db_connect($choices);

            require_once __DIR__.'/msg_functions.php';

            // create some variables that the sub functions need.
            if( !defined('CMS_ADODB_DT') ) define('CMS_ADODB_DT','DT');

            global $admin_user; //global var used downstream
            $admin_user = null; // no object
//          $db_prefix = CMS_DB_PREFIX;
            $dir = $app->get_appdir().'/install';
            if( !is_dir($dir) ) throw new Exception(lang('error_internal',805));

            // install the schema
            $this->message(lang('install_schema'));
            $fn = $dir.'/schema.php';
            if( !file_exists($fn) ) throw new Exception(lang('error_internal',806));

            global $CMS_INSTALL_DROP_TABLES, $CMS_INSTALL_CREATE_TABLES;
            $CMS_INSTALL_DROP_TABLES = 1; // TODO only for upgrades
            $CMS_INSTALL_CREATE_TABLES = 1;
            include_once $fn;

            // install sequence tables
            $this->verbose(lang('install_setsequence'));
            require_once $dir.'/createseq.php';

            if( $adminaccount['saltpw'] ) {
                $this->verbose(lang('install_passwordsalt'));
                $salt = substr(str_shuffle(md5($destdir).time()),0,16);
                cms_siteprefs::set('sitemask',$salt);
            }

            // create work directories for Smarty in tmp
            $this->verbose(lang('install_createtmpdirs'));
            @mkdir($destdir.'/tmp/cache',0777,TRUE);//TODO better 0775 or 0770 c.f. global_umask site-preference
            @mkdir($destdir.'/tmp/templates_c',0777,TRUE);

            require_once $dir.'/base.php';

            $this->message(lang('install_defaultcontent'));
            $fn = $dir.'/initial.php';
            if( $choices['samplecontent'] ) $fn = $dir.'/extra.php';
            require_once $fn;

            $this->verbose(lang('install_setsitename'));
            cms_siteprefs::set('sitename',$siteinfo['sitename']);

            // update all hierarchy positions
            $this->message(lang('install_updatehierarchy'));
            $contentops = cmsms()->GetContentOperations();
            $contentops->SetAllHierarchyPositions();

//          cms_siteprefs::set('global_umask','022'); installed default preferences in base.php included above
        }
        catch( Exception $e ) {
            $this->error($e->GetMessage());
        }
    }

    private function do_upgrade($version_info)
    {
        $app = get_app();
        $destdir = $app->get_destdir();
        if( !$destdir ) throw new Exception(lang('error_internal',811));

        $wiz = $this->get_wizard();
        $choices = $wiz->get_data('config');
        if( !$choices ) throw new Exception(lang('error_internal',812));

        // get the list of all available versions that this upgrader knows about
        $dir =  $app->get_appdir().'/upgrade';
        if( !is_dir($dir) ) throw new Exception(lang('error_internal',813));

        $dh = opendir($dir);
        if( !$dh ) throw new Exception(lang('error_internal',814));
        $versions = array();
        while( ($file = readdir($dh)) !== false ) {
            if( $file == '.' || $file == '..' ) continue;
            if( is_dir($dir.'/'.$file) && (is_file("$dir/$file/MANIFEST.DAT") || is_file("$dir/$file/MANIFEST.DAT.gz")) ) $versions[] = $file;
        }
        closedir($dh);
        if( count($versions) > 1) usort($versions,'version_compare');

        global $CMS_INSTALL_PAGE, $DONT_LOAD_DB, $DONT_LOAD_SMARTY, $CMS_VERSION;
        $CMS_INSTALL_PAGE = 1;
        $DONT_LOAD_DB = 1;
        $DONT_LOAD_SMARTY = 1;
        $CMS_VERSION = $app->get_dest_version();
        if( $app->in_phar() ) {
            global $CMS_PHAR_INSTALLER;
            $CMS_PHAR_INSTALLER = 1; //TODO used only to block core Smarty use c.f. $DONT_LOAD_SMARTY
        }

        // setup and initialize the CMSMS API's
        if( is_file("$destdir/lib/include.php") ) {
            include_once "$destdir/lib/include.php";
        }
        else if( is_file( "$destdir/include.php")) {
            include_once "$destdir/lib/include.php";
        }
        else {
            throw new RuntimeException('Could not find include.php file in destination');
        }

        try {
            $this->write_config($choices,$destdir);
            $this->connect_to_cmsms($destdir);
            // setup database connection
            $db = $this->db_connect($choices);

            $this->conform_langs($wiz,$db);

            require_once __DIR__.'/msg_functions.php';

           // ready to do the upgrading now (in a loop)
           // only perform upgrades for the versions known by the installer that are greater than what is installed.
            $current_version = $version_info['version'];
            foreach( $versions as $ver ) {
                $fn = "$dir/$ver/upgrade.php";
                if( version_compare($current_version,$ver) < 0 && is_file($fn) ) {
                    include_once($fn);
                }
            }

// former order $this->write_config($choices,$destdir);
//needed?   $this->connect_to_cmsms($destdir);
// TODO if upgrade may change content-pages, or (better) actually has done so,
// then update all hierarchy positions as for install operation

//          $this->verbose(lang('done'));
        }
        catch( Exception $e ) {
            $this->error($e->GetMessage());
        }
    }

    private function do_freshen()
    {
        $app = get_app();
        $destdir = $app->get_destdir();
        if( !$destdir ) throw new Exception(lang('error_internal',828));
        $wiz = $this->get_wizard();
        $choices = $wiz->get_data('config');
        if( !$choices ) throw new Exception(lang('error_internal',829));
        $this->connect_to_cmsms($destdir);
        // global flags $CMS_INSTALL_PAGE etc are still set, from prior method-call
        $config = cms_config::get_instance();
        if( $config['timezone'] != $choices['timezone'] ) {
            $this->write_config($choices,$destdir);
            // cleanup any message-creation scripts
            for( $i = 0,$n = count(ob_list_handlers()); $i < $n; $i++ ) {
                ob_end_clean();
            }
        }
        $db = $this->db_connect($choices);
        $this->conform_langs($wiz,$db);
    }

    private function conform_langs($wiz,$db)
    {
        $siteinfo = $wiz->get_data('siteinfo');
        if( !$siteinfo ) throw new Exception(lang('error_internal',831));
        $havelangs = [-3 => '',-2 => 'en_US'] + $siteinfo['extlanguages'];
        $filler = str_repeat('?,',count($havelangs) - 1);
        $sql = 'UPDATE '.CMS_DB_PREFIX."siteprefs SET sitepref_value='' WHERE sitepref_name='frontendlang' AND sitepref_value NOT IN({$filler}?)";
        $db->execute($sql,$havelangs);
        $sql = 'UPDATE '.CMS_DB_PREFIX."userprefs SET value='' WHERE preference='default_cms_language' AND value NOT IN({$filler}?)";
        $db->execute($sql,$havelangs);
    }

    private function write_config($choices,$destdir)
    {
        // [re]create config file
        // so that CMSMS can connect to the database.
        $fn = "$destdir/config.php";
        if( is_file($fn) ) {
            $this->verbose(lang('install_backupconfig'));
            $destfn = $destdir.'/bak.config.php';
            if( !copy($fn,$destfn) ) throw new Exception(lang('error_backupconfig'));
        }

        $newconfig = [];
        $newconfig['dbms'] = trim($choices['dbtype']);
        $newconfig['db_hostname'] = trim($choices['dbhost']);
        $newconfig['db_username'] = trim($choices['dbuser']);
        $newconfig['db_password'] = trim($choices['dbpass']);
        $newconfig['db_name'] = trim($choices['dbname']);
        $newconfig['db_prefix'] = trim($choices['dbprefix']);
        $newconfig['timezone'] = trim($choices['timezone']);
        if( $choices['query_var'] ) $newconfig['query_var'] = trim($choices['query_var']);
        if( isset($choices['dbport']) ) {
            $num = (int)$choices['dbport'];
            if( $num > 0 ) { $newconfig['db_port'] = $num; }
        }

        $this->message(lang('install_createconfig'));
        global $CMS_INSTALL_PAGE;
        $CMS_INSTALL_PAGE = 1;
        // get the system config instance, without fully connecting to cmsms
        $fp = $destdir.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR;
        // during an upgrade or freshen, these inclusions might already have been loaded, then cached by PHP
        require_once $fp.'misc.functions.php';
        require_once $fp.'classes'.DIRECTORY_SEPARATOR.'class.CmsApp.php';
        require_once $fp.'classes'.DIRECTORY_SEPARATOR.'class.cms_config.php';
        require_once $fp.'autoloader.php';
        $config = cms_config::get_instance();
        $config->merge($newconfig);
        if( !defined('CONFIG_FILE_LOCATION') ) {
            define('CONFIG_FILE_LOCATION', "$destdir/config.php");
        }
        $config->save();
        // double-check, in case there's PHP silliness
        if( !is_readable(CONFIG_FILE_LOCATION) ) {
            throw new Exception('Failed to record config file');
        }
    }

    protected function display()
    {
        $wiz = $this->get_wizard();
        $action = $wiz->get_data('action');
        if( $action != 'freshen' ) { // for freshens, we only cleanup config file and nls files here
            parent::display();
            $smarty = smarty();
            $smarty->assign('next_url',$wiz->next_url())
             ->display('wizard_step8.tpl');
        }

        // here, we do the action-specific stuff.
        try {
            switch( $action ) {
                case 'upgrade':
                    $tmp = $wiz->get_data('version_info'); // populated only for refreshes & upgrades
                    if( is_array($tmp) && count($tmp) ) {
                        $this->do_upgrade($tmp);
                        break;
                    }
                    else {
                        throw new Exception(lang('error_internal',840));
                    }
                    //no break here
                case 'freshen':
                    $this->do_freshen();
                    $url = $wiz->next_url();
                    utils::redirect($url);
                    break;
                case 'install':
                    $this->do_install();
                    break;
                default:
                    throw new Exception(lang('error_internal',841));
            }
        }
        catch( Exception $e ) {
            $this->error($e->GetMessage());
        }

        $this->finish();
    }
} // end of class

?>
